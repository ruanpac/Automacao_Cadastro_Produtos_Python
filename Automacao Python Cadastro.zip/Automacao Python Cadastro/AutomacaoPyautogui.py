import pyautogui
import time
import pandas as pd
import pyperclip

def preencher_val(val):
    pyautogui.press("Tab")

    if str(val) != "nan":
        pyperclip.copy(str(val))
        pyautogui.hotkey("ctrl", "v")
        time.sleep(0.1)
    #Se diferente de nan (n/a): digite, se nao, deixe em branco

#Passo 1 - Abrir navegador (Chrome)
pyautogui.press("Win")
pyautogui.write("Chrome")
time.sleep(0.5)
pyautogui.press("Enter")
time.sleep(0.5)

#Passo 2 - Abrir o site e digitar email/senha
time.sleep(0.25)
pyautogui.write("https://dlp.hashtagtreinamentos.com/python/intensivao/login")
pyautogui.press("Enter")
time.sleep(0.5)
pyautogui.press("Tab")
pyautogui.write("ruanpablopacola@gmail.com")
pyautogui.press("Tab")
pyautogui.write("ruan12345")
pyautogui.press("Tab")
pyautogui.press("Enter")
time.sleep(0.25)

#Passo 3 - Importar tabela para manipulação de dados
tabela = pd.read_excel("20produtos.xlsx")

for index in tabela.values:
    for valor in index:
        preencher_val(valor)

    #Enviar
    pyautogui.press("Tab")
    pyautogui.press("Enter")
    time.sleep(0.1)

    #Sair do botão enviar
    pyautogui.click(x=325, y=625)
    time.sleep(0.1)

print("\n\n\n######\nTabela Completa!\n######\n\n\n")